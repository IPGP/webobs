Markup language: 
Wiki

Description:
A basic Wiki markup set with Headings, Bold, Italic, Stroke through, Picture, Link, List, Quotes, Code, Preview button.

Install:
- Download the zip file
- Unzip it in your markItUp! sets folder
- Modify your JS link to point at this set.js
- Modify your CSS link to point at this style.css